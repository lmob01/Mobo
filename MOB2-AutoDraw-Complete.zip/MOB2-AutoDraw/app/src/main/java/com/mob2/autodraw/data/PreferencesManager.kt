package com.mob2.autodraw.data

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Rect

class PreferencesManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("mob2_drawing_prefs", Context.MODE_PRIVATE)

    fun saveLastDrawingBounds(rect: Rect) {
        prefs.edit()
            .putInt("bound_left", rect.left)
            .putInt("bound_top", rect.top)
            .putInt("bound_right", rect.right)
            .putInt("bound_bottom", rect.bottom)
            .apply()
    }

    fun getLastDrawingBounds(): Rect {
        val left = prefs.getInt("bound_left", 80)
        val top = prefs.getInt("bound_top", 250)
        val right = prefs.getInt("bound_right", 880)
        val bottom = prefs.getInt("bound_bottom", 1250)
        return Rect(left, top, right, bottom)
    }

    fun saveDrawingSpeed(speed: Int) {
        prefs.edit().putInt("drawing_speed", speed).apply()
    }

    fun getDrawingSpeed(): Int = prefs.getInt("drawing_speed", 6)

    fun saveDetailLevel(detail: Int) {
        prefs.edit().putInt("detail_level", detail).apply()
    }

    fun getDetailLevel(): Int = prefs.getInt("detail_level", 6)
}
