package com.mob2.autodraw

import android.app.Application
import android.util.Log

class MOB2Application : Application() {
    override fun onCreate() {
        super.onCreate()
        Log.i("MOB2App", "MOB 2 Application initialized successfully.")
    }
}
