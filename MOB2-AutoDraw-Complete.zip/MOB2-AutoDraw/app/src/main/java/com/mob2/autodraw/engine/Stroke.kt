package com.mob2.autodraw.engine

import android.graphics.PointF

data class Stroke(
    val id: String,
    val points: List<PointF>,
    val color: Int,
    val width: Float
)
