package com.mob2.autodraw.service

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.mob2.autodraw.R
import com.mob2.autodraw.data.PreferencesManager

class DrawingOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var selectionView: View? = null
    private var controlPillView: View? = null
    private lateinit var prefsManager: PreferencesManager

    companion object {
        var instance: DrawingOverlayService? = null
            private set
        const val CHANNEL_ID = "mob2_overlay_service_channel"
        const val NOTIFICATION_ID = 1002
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefsManager = PreferencesManager(this)
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "SHOW_SELECTION_FRAME" -> showSelectionFrame()
            "SHOW_CONTROL_PILL" -> showControlPill()
            "HIDE_SELECTION_FRAME" -> hideSelectionFrame()
            "STOP_SERVICE" -> stopSelf()
        }
        return START_STICKY
    }

    @SuppressLint("ClickableViewAccessibility")
    fun showSelectionFrame() {
        if (selectionView != null) return

        val savedBounds = prefsManager.getLastDrawingBounds()
        val layoutParamsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            savedBounds.width().coerceAtLeast(300),
            savedBounds.height().coerceAtLeast(300),
            layoutParamsType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = savedBounds.left.coerceAtLeast(50)
            y = savedBounds.top.coerceAtLeast(150)
        }

        val inflater = LayoutInflater.from(this)
        val frame = inflater.inflate(R.layout.overlay_selection_box, null)
        selectionView = frame

        val dragHeader = frame.findViewById<View>(R.id.overlay_drag_header)
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        dragHeader?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(frame, params)
                    prefsManager.saveLastDrawingBounds(
                        Rect(params.x, params.y, params.x + params.width, params.y + params.height)
                    )
                    true
                }
                else -> false
            }
        }

        windowManager.addView(frame, params)
    }

    fun hideSelectionFrame() {
        selectionView?.let {
            windowManager.removeView(it)
            selectionView = null
        }
    }

    fun showControlPill() {
        if (controlPillView != null) return

        val layoutParamsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val pillParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutParamsType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 30
            y = 200
        }

        val inflater = LayoutInflater.from(this)
        val pill = inflater.inflate(R.layout.overlay_control_pill, null)
        controlPillView = pill

        val btnPauseResume = pill.findViewById<Button>(R.id.btn_overlay_pause_resume)
        val btnStop = pill.findViewById<Button>(R.id.btn_overlay_stop)

        btnPauseResume?.setOnClickListener {
            val acc = DrawingAccessibilityService.instance
            acc?.pauseDrawing()
        }

        btnStop?.setOnClickListener {
            DrawingAccessibilityService.instance?.stopDrawing()
            hideControlPill()
        }

        windowManager.addView(pill, pillParams)
    }

    fun hideControlPill() {
        controlPillView?.let {
            windowManager.removeView(it)
            controlPillView = null
        }
    }

    fun updateProgress(current: Int, total: Int) {
        controlPillView?.let { pill ->
            val txtPercent = pill.findViewById<TextView>(R.id.overlay_txt_percent)
            val percent = if (total > 0) (current * 100) / total else 0
            txtPercent?.text = "$percent%"
        }
    }

    fun notifyDrawingCompleted() {
        hideControlPill()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "MOB 2 Drawing Overlay",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        hideSelectionFrame()
        hideControlPill()
        instance = null
    }
}
