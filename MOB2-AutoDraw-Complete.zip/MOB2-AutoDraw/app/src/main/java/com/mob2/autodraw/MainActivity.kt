package com.mob2.autodraw

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mob2.autodraw.data.PreferencesManager
import com.mob2.autodraw.engine.ImageVectorEngine
import com.mob2.autodraw.service.DrawingAccessibilityService
import com.mob2.autodraw.service.DrawingOverlayService

class MainActivity : ComponentActivity() {

    private lateinit var prefsManager: PreferencesManager
    private val vectorEngine = ImageVectorEngine()

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { handleImageSelected(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefsManager = PreferencesManager(this)

        setContent {
            MOB2Screen(
                onPickImage = { pickImageLauncher.launch("image/*") },
                onOpenAccessibility = { openAccessibilitySettings() },
                onOpenOverlay = { checkOverlayPermission() }
            )
        }
    }

    private fun handleImageSelected(uri: Uri) {
        try {
            val inputStream = contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()

            if (bitmap != null) {
                val bounds = prefsManager.getLastDrawingBounds()
                val strokes = vectorEngine.processBitmap(bitmap, 120, 6, bounds)

                Toast.makeText(this, "تم تحويل الصورة إلى ${strokes.size} مسار بنجاح!", Toast.LENGTH_SHORT).show()

                val acc = DrawingAccessibilityService.instance
                if (acc != null) {
                    acc.startDrawing(strokes, 0)
                    val overlayIntent = Intent(this, DrawingOverlayService::class.java).apply {
                        action = "SHOW_CONTROL_PILL"
                    }
                    startService(overlayIntent)
                } else {
                    Toast.makeText(this, "يرجى تفعيل خدمة إمكانية الوصول لبدء الرسم", Toast.LENGTH_LONG).show()
                    openAccessibilitySettings()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "خطأ أثناء قراءة الصورة: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        } else {
            val intent = Intent(this, DrawingOverlayService::class.java).apply {
                action = "SHOW_SELECTION_FRAME"
            }
            startService(intent)
            Toast.makeText(this, "تم إظهار إطار تحديد مساحة الرسم العائم", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        startActivity(intent)
    }
}

@Composable
fun MOB2Screen(
    onPickImage: () -> Unit,
    onOpenAccessibility: () -> Unit,
    onOpenOverlay: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0F172A)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "MOB 2",
                color = Color(0xFFF59E0B),
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "محرك الرسم التلقائي بمحاكاة يد الإنسان",
                color = Color(0xFF94A3B8),
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "الصلاحيات الأساسية المطلوبة",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onOpenAccessibility,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        Text("1. تفعيل خدمة إمكانية الوصول (Accessibility)", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = onOpenOverlay,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        Text("2. تفعيل النافذة العائمة وإظهار إطار التحديد", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onPickImage,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
            ) {
                Text("اختيار صورة من المعرض وبدء الرسم (JPG / PNG)", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
