package com.mob2.autodraw.engine

import android.graphics.PointF
import kotlin.math.*

object HumanHandSimulation {

    fun calculateDurationForStroke(length: Float, pointCount: Int, speedSetting: Int = 6): Long {
        val baseSpeedPxPerMs = 0.35f + (speedSetting * 0.18f)
        val density = pointCount / (length.coerceAtLeast(10f))
        val complexityMultiplier = (1.0f + (density * 1.5f)).coerceIn(1.0f, 2.5f)
        val durationMs = (length / baseSpeedPxPerMs) * complexityMultiplier
        return durationMs.toLong().coerceIn(40L, 4500L)
    }

    fun calculatePauseBetweenStrokes(lastStrokeLength: Float, pauseSettingMs: Long = 60L): Long {
        val cognitivePause = (lastStrokeLength / 150f).coerceIn(10f, 150f).toLong()
        return pauseSettingMs + cognitivePause
    }

    fun applyHumanJitter(point: PointF, jitterMagnitude: Float = 0.35f): PointF {
        if (jitterMagnitude <= 0f) return point
        val angle = Math.random() * 2 * Math.PI
        val r = Math.random() * jitterMagnitude
        val jx = (r * cos(angle)).toFloat()
        val jy = (r * sin(angle)).toFloat()
        return PointF(point.x + jx, point.y + jy)
    }
}
