package com.mob2.autodraw.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.mob2.autodraw.engine.HumanHandSimulation
import com.mob2.autodraw.engine.Stroke

class DrawingAccessibilityService : AccessibilityService() {

    private var isDrawing = false
    private var isPaused = false
    private var currentStrokeIndex = 0
    private var strokesToDraw: List<Stroke> = emptyList()
    private val handler = Handler(Looper.getMainLooper())

    companion object {
        var instance: DrawingAccessibilityService? = null
            private set
        const val TAG = "DrawingAccService"
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "MOB 2 Accessibility Service connected.")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopDrawing()
    }

    fun startDrawing(strokes: List<Stroke>, startIndex: Int = 0) {
        if (strokes.isEmpty()) return
        strokesToDraw = strokes
        currentStrokeIndex = startIndex
        isDrawing = true
        isPaused = false
        dispatchNextStroke()
    }

    fun pauseDrawing() {
        isPaused = true
        isDrawing = false
    }

    fun resumeDrawing() {
        if (isPaused && currentStrokeIndex < strokesToDraw.size) {
            isPaused = false
            isDrawing = true
            dispatchNextStroke()
        }
    }

    fun stopDrawing() {
        isDrawing = false
        isPaused = false
        currentStrokeIndex = 0
        strokesToDraw = emptyList()
    }

    private fun dispatchNextStroke() {
        if (!isDrawing || isPaused || currentStrokeIndex >= strokesToDraw.size) {
            if (currentStrokeIndex >= strokesToDraw.size && strokesToDraw.isNotEmpty()) {
                DrawingOverlayService.instance?.notifyDrawingCompleted()
            }
            return
        }

        val stroke = strokesToDraw[currentStrokeIndex]
        val points = stroke.points

        if (points.size < 2) {
            currentStrokeIndex++
            dispatchNextStroke()
            return
        }

        val path = Path()
        path.moveTo(points[0].x, points[0].y)

        for (i in 1 until points.size) {
            val prev = points[i - 1]
            val curr = points[i]
            val midX = (prev.x + curr.x) / 2f
            val midY = (prev.y + curr.y) / 2f
            path.quadTo(prev.x, prev.y, midX, midY)
        }
        val last = points.last()
        path.lineTo(last.x, last.y)

        var strokeLength = 0f
        for (i in 1 until points.size) {
            val dx = points[i].x - points[i - 1].x
            val dy = points[i].y - points[i - 1].y
            strokeLength += Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
        }

        val duration = HumanHandSimulation.calculateDurationForStroke(strokeLength, points.size, 6)
        val finalStrokeLength = strokeLength

        val strokeDescription = GestureDescription.StrokeDescription(
            path,
            0L,
            duration.coerceIn(50L, 5000L),
            false
        )

        val gestureBuilder = GestureDescription.Builder()
        gestureBuilder.addStroke(strokeDescription)

        dispatchGesture(gestureBuilder.build(), object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                currentStrokeIndex++
                DrawingOverlayService.instance?.updateProgress(
                    currentStrokeIndex,
                    strokesToDraw.size
                )

                val pauseMs = HumanHandSimulation.calculatePauseBetweenStrokes(finalStrokeLength, 60L)
                handler.postDelayed({
                    if (isDrawing && !isPaused) {
                        dispatchNextStroke()
                    }
                }, pauseMs)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                super.onCancelled(gestureDescription)
            }
        }, null)
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }
}
