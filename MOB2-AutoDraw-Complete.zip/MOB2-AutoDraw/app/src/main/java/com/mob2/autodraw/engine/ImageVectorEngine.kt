package com.mob2.autodraw.engine

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PointF
import android.graphics.Rect
import kotlin.math.hypot
import kotlin.math.sqrt

class ImageVectorEngine {

    fun processBitmap(
        bitmap: Bitmap,
        threshold: Int = 120,
        detailLevel: Int = 6,
        targetBounds: Rect? = null
    ): List<Stroke> {
        val width = bitmap.width
        val height = bitmap.height

        // 1. Grayscale & Sobel Edge Detection
        val gray = IntArray(width * height)
        for (y in 0 until height) {
            for (x in 0 until width) {
                val pixel = bitmap.getPixel(x, y)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)
                gray[y * width + x] = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
            }
        }

        val edges = BooleanArray(width * height)
        for (y in 1 until height - 1) {
            for (x in 1 until width - 1) {
                val idx = y * width + x
                val gx = -gray[idx - width - 1] + gray[idx - width + 1] +
                        -2 * gray[idx - 1] + 2 * gray[idx + 1] +
                        -gray[idx + width - 1] + gray[idx + width + 1]
                val gy = -gray[idx - width - 1] - 2 * gray[idx - width] - gray[idx - width + 1] +
                        gray[idx + width - 1] + 2 * gray[idx + width] + gray[idx + width + 1]
                val mag = sqrt((gx * gx + gy * gy).toDouble()).toInt()
                edges[idx] = mag > threshold
            }
        }

        // 2. Contour Path Tracing
        val visited = BooleanArray(width * height)
        val rawStrokes = mutableListOf<List<PointF>>()
        val directions = arrayOf(
            Pair(-1, 0), Pair(1, 0), Pair(0, -1), Pair(0, 1),
            Pair(-1, -1), Pair(1, 1), Pair(-1, 1), Pair(1, -1)
        )

        for (y in 1 until height - 1 step 2) {
            for (x in 1 until width - 1 step 2) {
                val startIdx = y * width + x
                if (edges[startIdx] && !visited[startIdx]) {
                    val pts = mutableListOf<PointF>()
                    pts.add(PointF(x.toFloat(), y.toFloat()))
                    visited[startIdx] = true

                    var cx = x
                    var cy = y
                    var tracing = true
                    var steps = 0

                    while (tracing && steps < 800) {
                        steps++
                        var found = false
                        for ((dx, dy) in directions) {
                            val nx = cx + dx
                            val ny = cy + dy
                            if (nx in 0 until width && ny in 0 until height) {
                                val nIdx = ny * width + nx
                                if (edges[nIdx] && !visited[nIdx]) {
                                    visited[nIdx] = true
                                    cx = nx
                                    cy = ny
                                    pts.add(PointF(cx.toFloat(), cy.toFloat()))
                                    found = true
                                    break
                                }
                            }
                        }
                        if (!found) tracing = false
                    }

                    if (pts.size >= 4) {
                        rawStrokes.add(pts)
                    }
                }
            }
        }

        // 3. Simplify with Douglas-Peucker
        val tolerance = 1.2f + (10 - detailLevel) * 0.4f
        val simplifiedStrokes = rawStrokes.map { douglasPeucker(it, tolerance) }

        // 4. TSP Nearest-Neighbor Ordering
        val orderedStrokes = orderNearestNeighbor(simplifiedStrokes)

        // 5. Fit within target overlay bounds
        return if (targetBounds != null) {
            fitToTargetBounds(orderedStrokes, width, height, targetBounds)
        } else {
            orderedStrokes.mapIndexed { i, pts ->
                Stroke("stroke_$i", pts, Color.BLACK, 4f)
            }
        }
    }

    private fun douglasPeucker(points: List<PointF>, epsilon: Float): List<PointF> {
        if (points.size <= 2) return points
        var dmax = 0f
        var index = 0
        val end = points.size - 1

        for (i in 1 until end) {
            val d = perpendicularDistance(points[i], points[0], points[end])
            if (d > dmax) {
                index = i
                dmax = d
            }
        }

        return if (dmax > epsilon) {
            val rec1 = douglasPeucker(points.subList(0, index + 1), epsilon)
            val rec2 = douglasPeucker(points.subList(index, points.size), epsilon)
            rec1.dropLast(1) + rec2
        } else {
            listOf(points.first(), points.last())
        }
    }

    private fun perpendicularDistance(p: PointF, lineStart: PointF, lineEnd: PointF): Float {
        val dx = lineEnd.x - lineStart.x
        val dy = lineEnd.y - lineStart.y
        val mag = hypot(dx.toDouble(), dy.toDouble()).toFloat()
        if (mag == 0f) return hypot((p.x - lineStart.x).toDouble(), (p.y - lineStart.y).toDouble()).toFloat()
        return kotlin.math.abs(dy * p.x - dx * p.y + lineEnd.x * lineStart.y - lineEnd.y * lineStart.x) / mag
    }

    private fun orderNearestNeighbor(raw: List<List<PointF>>): List<List<PointF>> {
        if (raw.size <= 1) return raw
        val remaining = raw.toMutableList()
        val result = mutableListOf<List<PointF>>()

        var current = remaining.removeAt(0)
        result.add(current)

        while (remaining.isNotEmpty()) {
            val lastPoint = current.last()
            var nearestIdx = 0
            var minDist = Float.MAX_VALUE
            var shouldReverse = false

            for (i in remaining.indices) {
                val cand = remaining[i]
                val dStart = hypot((cand.first().x - lastPoint.x).toDouble(), (cand.first().y - lastPoint.y).toDouble()).toFloat()
                val dEnd = hypot((cand.last().x - lastPoint.x).toDouble(), (cand.last().y - lastPoint.y).toDouble()).toFloat()

                if (dStart < minDist) {
                    minDist = dStart
                    nearestIdx = i
                    shouldReverse = false
                }
                if (dEnd < minDist) {
                    minDist = dEnd
                    nearestIdx = i
                    shouldReverse = true
                }
            }

            var next = remaining.removeAt(nearestIdx)
            if (shouldReverse) next = next.reversed()
            result.add(next)
            current = next
        }

        return result
    }

    private fun fitToTargetBounds(
        strokes: List<List<PointF>>,
        srcW: Int,
        srcH: Int,
        bounds: Rect
    ): List<Stroke> {
        val scale = minOf(
            (bounds.width() * 0.92f) / srcW.toFloat(),
            (bounds.height() * 0.92f) / srcH.toFloat()
        )
        val fittedW = srcW * scale
        val fittedH = srcH * scale
        val offsetX = bounds.left + (bounds.width() - fittedW) / 2f
        val offsetY = bounds.top + (bounds.height() - fittedH) / 2f

        return strokes.mapIndexed { idx, pts ->
            val transformed = pts.map { p ->
                PointF(offsetX + p.x * scale, offsetY + p.y * scale)
            }
            Stroke("stroke_$idx", transformed, Color.BLACK, 4f)
        }
    }
}
